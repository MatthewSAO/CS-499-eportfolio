#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <algorithm>
#include <vector>

using namespace std;

// Function to load item data from file into unordered_map
unordered_map<string, int> LoadItemData(const string& filename) {
    unordered_map<string, int> itemFrequency;
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error: File could not be opened.\n";
        return itemFrequency;
    }

    string item;
    while (getline(file, item)) {
        if (!item.empty()) {
            transform(item.begin(), item.end(), item.begin(), ::tolower);
            itemFrequency[item]++;
        }
    }

    return itemFrequency;
}

// Function to print item frequencies
void PrintFrequencies(const unordered_map<string, int>& itemFrequency) {
    for (const auto& pair : itemFrequency) {
        cout << pair.first << ": " << pair.second << endl;
    }
}

// Function to search for an item frequency
void SearchItem(const unordered_map<string, int>& itemFrequency, const string& item) {
    string lowercaseItem = item;
    transform(lowercaseItem.begin(), lowercaseItem.end(), lowercaseItem.begin(), ::tolower);

    auto it = itemFrequency.find(lowercaseItem);
    if (it != itemFrequency.end()) {
        cout << item << " occurs " << it->second << " times." << endl;
    } else {
        cout << item << " not found." << endl;
    }
}

// Function to print items sorted by frequency
void PrintSortedByFrequency(const unordered_map<string, int>& itemFrequency) {
    vector<pair<string, int>> items(itemFrequency.begin(), itemFrequency.end());

    sort(items.begin(), items.end(), [](const auto& a, const auto& b) {
        return a.second > b.second;
    });

    for (const auto& item : items) {
        cout << item.first << ": " << item.second << endl;
    }
}

int main() {
    string filename = "CS210_Project_Three_Input_File.txt";
    unordered_map<string, int> itemFrequency = LoadItemData(filename);

    if (itemFrequency.empty()) {
        return 1;
    }

    int choice;
    do {
        cout << "\nMenu:\n";
        cout << "1. Print Item Frequencies\n";
        cout << "2. Search for an Item\n";
        cout << "3. Print Histogram\n";
        cout << "4. Print Items Sorted by Frequency\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Invalid input. Please try again.\n";
            continue;
        }

        string item;
        switch (choice) {
            case 1:
                PrintFrequencies(itemFrequency);
                break;
            case 2:
                cout << "Enter item to search: ";
                cin >> item;
                SearchItem(itemFrequency, item);
                break;
            case 3:
                for (const auto& pair : itemFrequency) {
                    cout << pair.first << ": ";
                    for (int i = 0; i < pair.second; ++i) {
                        cout << "*";
                    }
                    cout << endl;
                }
                break;
            case 4:
                PrintSortedByFrequency(itemFrequency);
                break;
            case 5:
                cout << "Exiting.\n";
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 5);

    return 0;
}
