// CS250 - Grocery Item Tracker 
// Matthew Ohlemacher


#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <algorithm>
#include <vector>
#include <limits>
using namespace std;

// Load items from file and count how often each appears
unordered_map<string, int> LoadItemData(const string& filename) {
    unordered_map<string, int> itemFrequency;
    ifstream file(filename);
    if (!file.is_open()) { 
        cerr << "Error: cannot open file.\n"; 
        return itemFrequency; 
    }
    string item;
    while (file >> item) {
        transform(item.begin(), item.end(), item.begin(), ::tolower);
        itemFrequency[item]++;
    }
    return itemFrequency;
}

// Print all items and their frequencies
void PrintFrequencies(const unordered_map<string, int>& freq) {
    cout << "------------------------------------\n";
    for (const auto& p : freq) cout << p.first << ": " << p.second << "\n";
    cout << "------------------------------------\n";
}

// Search for a single item and print result
void SearchItem(const unordered_map<string, int>& freq, string item) {
    transform(item.begin(), item.end(), item.begin(), ::tolower);
    auto it = freq.find(item);
    if (it != freq.end()) cout << item << " occurs " << it->second << " times.\n";
    else cout << item << " not found.\n";
}

// Print a simple text histogram of item frequencies
void PrintHistogram(const unordered_map<string, int>& freq) {
    cout << "------------------------------------\n";
    for (const auto& p : freq) {
        cout << p.first << ": ";
        for (int i = 0; i < p.second; ++i) cout << "*";
        cout << "\n";
    }
    cout << "------------------------------------\n";
}

// Print items sorted by how often they appear (highest first)
void PrintSortedByFrequency(const unordered_map<string, int>& freq) {
    vector<pair<string,int>> items(freq.begin(), freq.end());
    sort(items.begin(), items.end(), 
         [](const auto& a, const auto& b){ return a.second > b.second; });
    cout << "---- Sorted by Frequency (desc) ----\n";
    for (const auto& it : items) cout << it.first << ": " << it.second << "\n";
}

int main() {
    string filename = "Input_File.txt";
    auto freq = LoadItemData(filename);
    if (freq.empty()) { 
        cerr << "No data loaded. Exiting.\n"; 
        return 1; 
    }

    int choice;
    do {
        // Main menu
        cout << "\nMenu:\n";
        cout << "1. Print Item Frequencies\n";
        cout << "2. Search for an Item\n";
        cout << "3. Print Histogram\n";
        cout << "4. Print Items Sorted by Frequency\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (cin.fail()) { 
            cin.clear(); 
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cout << "Invalid input.\n"; 
            continue; 
        }

        string item;
        switch (choice) {
            case 1: PrintFrequencies(freq); break;
            case 2: cout << "Enter item: "; cin >> item; SearchItem(freq, item); break;
            case 3: PrintHistogram(freq); break;
            case 4: PrintSortedByFrequency(freq); break;
            case 5: cout << "Exiting.\n"; break;
            default: cout << "Invalid choice.\n";
        }
    } while (choice != 5);

    return 0;
}