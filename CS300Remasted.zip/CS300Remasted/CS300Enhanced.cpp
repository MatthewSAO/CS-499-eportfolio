// Matthew Ohlemacher
// CS 300 - Enhanced Course Planner
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <limits>
using namespace std;

// Course class to store course information
class Course {
public:
    string courseNumber;
    string courseName;
    vector<string> preReqs;

    Course(string number, string name) : courseNumber(number), courseName(name) {}
};

// Student class to track student enrollments
class Student {
public:
    string studentId;
    string name;
    vector<string> enrolledCourses;

    Student(string id, string n) : studentId(id), name(n) {}
};

// Function to load courses from file
void LoadCourses(const string& filename, unordered_map<string, Course>& courses) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Unable to open file." << endl;
        return;
    }
    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string courseNumber, courseName, preReq;
        vector<string> preReqs;

        getline(ss, courseNumber, ',');
        getline(ss, courseName, ',');

        while (getline(ss, preReq, ',')) {
            preReqs.push_back(preReq);
        }

        Course course(courseNumber, courseName);
        course.preReqs = preReqs;
        courses.insert({ courseNumber, course });
    }
    file.close();
    cout << "Courses loaded successfully." << endl;
}

// Print all courses in order
void PrintCourseList(const unordered_map<string, Course>& courses) {
    vector<string> courseNumbers;
    for (const auto& pair : courses) {
        courseNumbers.push_back(pair.first);
    }
    sort(courseNumbers.begin(), courseNumbers.end());
    for (const auto& courseNumber : courseNumbers) {
        cout << courseNumber << ": " << courses.at(courseNumber).courseName << endl;
    }
}

// Print details for a specific course
void PrintCourseInfo(const unordered_map<string, Course>& courses, const string& courseNumber) {
    auto it = courses.find(courseNumber);
    if (it != courses.end()) {
        const Course& course = it->second;
        cout << "Course Number: " << course.courseNumber << endl;
        cout << "Title: " << course.courseName << endl;
        if (!course.preReqs.empty()) {
            cout << "Prerequisites:" << endl;
            for (const auto& prereq : course.preReqs) {
                cout << "  - " << prereq << endl;
            }
        } else {
            cout << "No prerequisites." << endl;
        }
    } else {
        cout << "Course " << courseNumber << " not found." << endl;
    }
}

// Grade book structure: studentId -> courseId -> grade
unordered_map<string, unordered_map<string, char>> gradeBook;

// View a student transcript
void ViewStudentTranscript(const Student& student) {
    cout << "Transcript for " << student.name << " (" << student.studentId << "):" << endl;
    if (student.enrolledCourses.empty()) {
        cout << "No courses enrolled." << endl;
        return;
    }
    for (const auto& course : student.enrolledCourses) {
        char grade = gradeBook[student.studentId][course];
        cout << "Course: " << course << " Grade: " << (grade ? grade : '-') << endl;
    }
}

// Enroll student in a course
void EnrollStudent(Student& student, const string& courseId) {
    student.enrolledCourses.push_back(courseId);
    gradeBook[student.studentId][courseId] = '-'; // default grade placeholder
    cout << "Enrolled " << student.name << " in " << courseId << endl;
}

// Assign grade to a student
void AssignGrade(Student& student, const string& courseId, char grade) {
    gradeBook[student.studentId][courseId] = grade;
    cout << "Assigned grade " << grade << " for " << student.name << " in " << courseId << endl;
}

// Display menu
void DisplayMenu(unordered_map<string, Course>& courses, Student& student) {
    int choice;
    string filename, courseNumber;
    char grade;

    do {
        cout << "\nMenu:\n";
        cout << "1: Load Data from File\n";
        cout << "2: Print All Courses\n";
        cout << "3: Print Course Info\n";
        cout << "4: Enroll in a Course\n";
        cout << "5: Assign Grade\n";
        cout << "6: View Transcript\n";
        cout << "9: Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid choice. Please try again." << endl;
            continue;
        }

        switch (choice) {
            case 1:
                cout << "Enter filename: ";
                cin >> filename;
                LoadCourses(filename, courses);
                break;
            case 2:
                PrintCourseList(courses);
                break;
            case 3:
                cout << "Enter course number: ";
                cin >> courseNumber;
                PrintCourseInfo(courses, courseNumber);
                break;
            case 4:
                cout << "Enter course number to enroll: ";
                cin >> courseNumber;
                EnrollStudent(student, courseNumber);
                break;
            case 5:
                cout << "Enter course number: ";
                cin >> courseNumber;
                cout << "Enter grade: ";
                cin >> grade;
                AssignGrade(student, courseNumber, grade);
                break;
            case 6:
                ViewStudentTranscript(student);
                break;
            case 9:
                cout << "Exiting program." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 9);
}

int main() {
    unordered_map<string, Course> courses;
    Student student("S001", "John Doe");
    DisplayMenu(courses, student);
    return 0;
}
