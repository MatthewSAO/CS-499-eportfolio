// CS300 Course Planner Benchmark
// Compares std::map vs std::unordered_map for load + lookup on the same dataset.
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <map>
#include <unordered_map>
#include <algorithm>
#include <chrono>
#include <random>

struct Course {
    std::string courseNumber;
    std::string courseName;
    std::vector<std::string> preReqs;
};

std::vector<Course> LoadRawCourses(const std::string& filename) {
    std::vector<Course> out;
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Unable to open file: " << filename << "\n";
        return out;
    }
    std::string line;
    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string courseNumber, courseName, preReq;
        std::vector<std::string> preReqs;
        std::getline(ss, courseNumber, ',');
        std::getline(ss, courseName, ',');
        while (std::getline(ss, preReq, ',')) {
            preReqs.push_back(preReq);
        }
        out.push_back({courseNumber, courseName, preReqs});
    }
    return out;
}

int main(int argc, char** argv) {
    std::string filename = "courses_data.txt";
    if (argc > 1) filename = argv[1];

    auto raw = LoadRawCourses(filename);
    if (raw.empty()) {
        std::cerr << "No data loaded.\n";
        return 1;
    }

    // Load into std::map
    auto t1 = std::chrono::steady_clock::now();
    std::map<std::string, Course> mapCourses;
    for (auto& c : raw) mapCourses[c.courseNumber] = c;
    auto t2 = std::chrono::steady_clock::now();
    auto map_load_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t2 - t1).count();

    // Load into std::unordered_map
    auto t3 = std::chrono::steady_clock::now();
    std::unordered_map<std::string, Course> umapCourses;
    umapCourses.reserve(raw.size() * 2);
    for (auto& c : raw) umapCourses[c.courseNumber] = c;
    auto t4 = std::chrono::steady_clock::now();
    auto umap_load_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t4 - t3).count();

    // Prepare lookup keys (repeat lookups many times)
    std::vector<std::string> keys;
    keys.reserve(raw.size() * 200);
    for (int rep = 0; rep < 200; ++rep) {
        for (auto& c : raw) keys.push_back(c.courseNumber);
    }
    std::shuffle(keys.begin(), keys.end(), std::mt19937{std::random_device{}()});

    // Lookup timings: map
    auto t5 = std::chrono::steady_clock::now();
    size_t hits_map = 0;
    for (auto& k : keys) {
        auto it = mapCourses.find(k);
        if (it != mapCourses.end()) ++hits_map;
    }
    auto t6 = std::chrono::steady_clock::now();
    auto map_lookup_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t6 - t5).count();

    // Lookup timings: unordered_map
    auto t7 = std::chrono::steady_clock::now();
    size_t hits_umap = 0;
    for (auto& k : keys) {
        auto it = umapCourses.find(k);
        if (it != umapCourses.end()) ++hits_umap;
    }
    auto t8 = std::chrono::steady_clock::now();
    auto umap_lookup_ms = std::chrono::duration_cast<std::chrono::milliseconds>(t8 - t7).count();

    std::cout << "Records: " << raw.size() << "\n";
    std::cout << "[std::map]         load: " << map_load_ms << " ms, lookups: " << map_lookup_ms << " ms, hits: " << hits_map << "\n";
    std::cout << "[std::unordered_map] load: " << umap_load_ms << " ms, lookups: " << umap_lookup_ms << " ms, hits: " << hits_umap << "\n";
    return 0;
}
