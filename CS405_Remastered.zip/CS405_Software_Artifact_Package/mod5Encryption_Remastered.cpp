// CS405 - File Encryption
// Matthew Ohlemacher

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>
#include <string>
using namespace std;

// Log file to record events and errors
static const string LOG_FILE = "encryption_log.txt";

// Write a timestamped message to the log file
void log_event(const string& msg) {
    ofstream log(LOG_FILE, ios::app);
    if (log) {
        time_t now = time(nullptr);
        tm local_time{};
        #ifdef _WIN32
            localtime_s(&local_time, &now);
        #else
            localtime_r(&now, &local_time);
        #endif
        log << (1900 + local_time.tm_year) << "-"
            << setw(2) << setfill('0') << (1 + local_time.tm_mon) << "-"
            << setw(2) << setfill('0') << local_time.tm_mday << " "
            << setw(2) << setfill('0') << local_time.tm_hour << ":"
            << setw(2) << setfill('0') << local_time.tm_min  << ":"
            << setw(2) << setfill('0') << local_time.tm_sec  << " | "
            << msg << endl;
    }
}

// XOR cipher: same function handles encrypt and decrypt
string encrypt_decrypt(const string& source, const string& key) {
    const auto kl = key.length();
    const auto sl = source.length();
    assert(kl > 0 && sl > 0);
    string out = source;
    for (size_t i = 0; i < sl; ++i)
        out[i] = source[i] ^ key[i % kl];
    return out;
}

// Read file contents into a string
string read_file(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Failed to open: " << filename << endl;
        log_event("ERROR opening " + filename);
        return "";
    }
    ostringstream ss; ss << file.rdbuf();
    log_event("Read file: " + filename);
    return ss.str();
}

// Save student, date, key, and data to a file
void save_data_file(const string& filename, const string& student_name,
                    const string& key, const string& data) {
    ofstream file(filename);
    if (!file.is_open()) {
        cerr << "Failed to write: " << filename << endl;
        log_event("ERROR writing " + filename);
        return;
    }
    time_t now = time(nullptr); tm lt{};
    #ifdef _WIN32
        localtime_s(&lt, &now);
    #else
        localtime_r(&now, &lt);
    #endif
    file << student_name << endl;
    file << (1900 + lt.tm_year) << "-" << setw(2) << setfill('0')
         << (1 + lt.tm_mon) << "-" << setw(2) << setfill('0') << lt.tm_mday << endl;
    file << key << endl;
    file << data;
    log_event("Wrote file: " + filename);
}

// Pull student name (first line of data)
string get_student_name(const string& data) {
    size_t pos = data.find('\n');
    return (pos != string::npos) ? data.substr(0, pos) : "Unknown Student";
}

// Main program: read input, encrypt, decrypt, save, log steps
int main() {
    cout << "CS405 File Encryption (Enhanced)\n";

    const string inputFile = "inputdatafile.txt";
    const string encFile   = "encrypteddatafile.txt";
    const string decFile   = "decrypteddatafile.txt";
    const string key       = "password";

    string src = read_file(inputFile);
    if (src.empty()) {
        cerr << "No input data.\n";
        return 1;
    }

    string student = get_student_name(src);

    string enc = encrypt_decrypt(src, key);
    save_data_file(encFile, student, key, enc);

    string dec = encrypt_decrypt(enc, key);
    save_data_file(decFile, student, key, dec);

    cout << "Done. Encrypted -> " << encFile
         << ", Decrypted -> " << decFile << "\n";
    return 0;
}
